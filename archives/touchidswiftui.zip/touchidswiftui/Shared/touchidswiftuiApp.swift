//
//  touchidswiftuiApp.swift
//  Shared
//
//  Created by Andy Ibanez on 5/9/21.
//

import SwiftUI

@main
struct touchidswiftuiApp: App {
    @StateObject var appContext = AppContext()
    
    var body: some Scene {
        WindowGroup {
            ZStack {
                if appContext.appUnlocked {
                    MainApp()
                        .animation(.default)
                        .transition(.move(edge: .bottom))
                } else {
                    FaceIDLoginView(appContext: appContext)
                        .background(Color.white)
                        .animation(.default)
                        .transition(.move(edge: .top))
                }
            }
        }
    }
}
