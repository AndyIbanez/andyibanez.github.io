//
//  MainApp.swift
//  touchidswiftui
//
//  Created by Andy Ibanez on 5/9/21.
//

import SwiftUI

struct MainApp: View {
    var body: some View {
        TabView {
            Text("Secret Page one")
                .tabItem {
                    Label("My Secrets", systemImage: "lock.doc")
                }
            
            Text("Secret page two")
                .tabItem {
                    Label("Your secrets", systemImage: "lock.square")
                }
        }
    }
}

struct MainApp_Previews: PreviewProvider {
    static var previews: some View {
        MainApp()
    }
}
