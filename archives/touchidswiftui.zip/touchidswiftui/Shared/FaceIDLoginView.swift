//
//  FaceIDLoginView.swift
//  touchidswiftui
//
//  Created by Andy Ibanez on 5/9/21.
//

import SwiftUI

struct FaceIDLoginView: View {
    @ObservedObject var appContext: AppContext
    
    var body: some View {
        VStack(spacing: 24) {
            Image(systemName: "faceid")
                .resizable()
                .frame(width: 150, height: 150)
            
            Button(action: {
                appContext.requestBiometricUnlock()
            }, label: {
                HStack {
                    Spacer()
                    Text("Login now")
                        .fontWeight(.bold)
                    Spacer()
                }
                .padding(10)
                .background(Color.blue)
                .foregroundColor(.white)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            })
        }
        .padding()
    }
}

struct FaceIDLoginView_Previews: PreviewProvider {
    static var previews: some View {
        FaceIDLoginView(appContext: AppContext())
    }
}
