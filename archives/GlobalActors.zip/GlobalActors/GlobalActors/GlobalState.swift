//
//  GlobalState.swift
//  GlobalState
//
//  Created by Andy Ibanez on 8/8/21.
//

import Foundation

// IMPORTANT NOTE: This entire project simply exists to teach people how to use global actors.
// I do not condone the use of global state in this way.
//
// Program responsibly.

@globalActor
struct MediaActor {
  actor ActorType { }

  static let shared: ActorType = ActorType()
}

struct Videogame {
    let id = UUID()
    let name: String
    let releaseYear: Int
    let developer: String
}

@MediaActor var videogames: [Videogame] = []
