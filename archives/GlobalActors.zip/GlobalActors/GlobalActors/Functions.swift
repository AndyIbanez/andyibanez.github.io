//
//  Functions.swift
//  Functions
//
//  Created by Andy Ibanez on 8/8/21.
//

import Foundation

@MediaActor
func showAvailableGames() async {
    for game in videogames {
        print("\(game.name)")
    }
}
