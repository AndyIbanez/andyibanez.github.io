//
//  Core_Location_TestApp.swift
//  Shared
//
//  Created by Andy Ibanez on 3/13/21.
//

import SwiftUI

@main
struct Core_Location_TestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
