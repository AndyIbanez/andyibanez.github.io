//
//  Notification.Name+Extensions.swift
//  bgTasks
//
//  Created by Andy Ibanez on 12/9/19.
//  Copyright © 2019 BNB. All rights reserved.
//

import Foundation

extension Notification.Name {
  static let newPokemonFetched = Notification.Name("com.andyibanez.newPokemonFetched")
}
