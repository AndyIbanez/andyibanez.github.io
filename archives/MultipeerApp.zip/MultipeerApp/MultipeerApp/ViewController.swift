//
//  ViewController.swift
//  MultipeerApp
//
//  Created by Andy Ibanez on 7/12/20.
//  Copyright © 2020 Fairese. All rights reserved.
//

import UIKit
import MultipeerConnectivity

class ViewController: UIViewController, MCSessionDelegate, MCNearbyServiceAdvertiserDelegate, MCNearbyServiceBrowserDelegate {
    
    
    var advertiser: MCNearbyServiceAdvertiser?
    
    let serviceType = "MPCTutorial"
    
    var myId = MCPeerID(displayName: UIDevice.current.name)
    
    var browser: MCNearbyServiceBrowser?
    
    var session: MCSession?
    
    var connectedPeer: MCPeerID?
    
    @IBAction func becomeAdvertiserButtonTapped(_ sender: Any) {
        becomeAdvertiser()
    }
    
    @IBAction func searchForDevicesButtonTapped(_ sender: Any) {
        searchForDevices()
    }
    
    
    @IBAction func sendImageButtonPressed(_ sender: Any) {
        sendImage(toPeer: connectedPeer!)
    }
    
    @IBOutlet weak var imageView: UIImageView!
    
    
    func becomeAdvertiser() {
        let discoveryInfo = [
            "Device Type": UIDevice.current.model,
            "OS": UIDevice.current.systemName,
            "OS Version": UIDevice.current.systemVersion
        ]
        
        advertiser = MCNearbyServiceAdvertiser(peer: myId, discoveryInfo: discoveryInfo, serviceType: serviceType)
        
        advertiser?.delegate = self
        
        advertiser?.startAdvertisingPeer()
    }
    
    func searchForDevices() {
        browser = MCNearbyServiceBrowser(peer: myId, serviceType: serviceType)
        
        browser?.delegate = self

        browser?.startBrowsingForPeers()
    }
    
    // MARK: - MCNearbyServiceAdvertiserDelegate
    
    func advertiser(_ advertiser: MCNearbyServiceAdvertiser, didReceiveInvitationFromPeer peerID: MCPeerID, withContext context: Data?, invitationHandler: @escaping (Bool, MCSession?) -> Void) {
        print("Invitation to connect from \(peerID.displayName)")
        print("Accepting invite")
        session = MCSession(peer: myId)
        session?.delegate = self
        invitationHandler(true, session)
        
    }
    
    func invitePeerToConnect(peerID: MCPeerID) {
        session = MCSession(peer: myId)
        session?.delegate = self
        self.connectedPeer = peerID
        browser?.invitePeer(peerID, to: session!, withContext: nil, timeout: 30)
    }
    
    func sendImage(toPeer peer: MCPeerID) {
        let bundledImage = Bundle.main.url(forResource: "cucoo", withExtension: "png")!
        let imageData = try! Data(contentsOf: bundledImage)
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1)) {
            try! self.session?.send(imageData, toPeers: [peer], with: .reliable)
        }
    }
    
    
    // MARK: - MCSession Delegate
    
    func session(_ session: MCSession, peer peerID: MCPeerID, didChange state: MCSessionState) {
        print("changed state \(state.rawValue)")
        if state == .connected {
            print("Ready to send image")
        }
    }
    
    func session(_ session: MCSession, didReceive data: Data, fromPeer peerID: MCPeerID) {
        print("Did receive data")
        if let imageData = UIImage(data: data) {
            DispatchQueue.main.async {
                self.imageView.image = imageData
            }
        }
    }
    
    func session(_ session: MCSession, didReceive stream: InputStream, withName streamName: String, fromPeer peerID: MCPeerID) {
    }
    
    func session(_ session: MCSession, didStartReceivingResourceWithName resourceName: String, fromPeer peerID: MCPeerID, with progress: Progress) {
        
    }
    
    func session(_ session: MCSession, didFinishReceivingResourceWithName resourceName: String, fromPeer peerID: MCPeerID, at localURL: URL?, withError error: Error?) {
        
    }
    
    // MARK: - MCNearbyServiceBrowserDelegate
    
    func browser(_ browser: MCNearbyServiceBrowser, foundPeer peerID: MCPeerID, withDiscoveryInfo info: [String : String]?) {
        print("We found a peer!")
        print("ID: \(peerID.displayName)")
        print("Device Type: \(info?["Device Type"] ?? "")")
        print("Version: \(info?["OS Version"] ?? "")")
        
        invitePeerToConnect(peerID: peerID)
    }
    
    func browser(_ browser: MCNearbyServiceBrowser, lostPeer peerID: MCPeerID) {
        print("We lost peer \(peerID.displayName)")
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

}
