//
//  ViewController.swift
//  AsyncAwaitContactPicker
//
//  Created by Andy Ibanez on 6/17/21.
//

import UIKit
import ContactsUI

@MainActor
class ContactPicker: NSObject, CNContactPickerDelegate {
    private typealias ContactCheckedContinuation = CheckedContinuation<CNContact?, Never>
    
    private unowned var viewController: UIViewController
    private var contactContinuation: ContactCheckedContinuation?
    private var picker: CNContactPickerViewController
    
    init(viewController: UIViewController) {
        self.viewController = viewController
        picker = CNContactPickerViewController()
        super.init()
        picker.delegate = self
    }
    
    func pickContact() async -> CNContact? {
        viewController.present(picker, animated: true)
        return await withCheckedContinuation({ (continuation: ContactCheckedContinuation) in
            self.contactContinuation = continuation
        })
    }
    
    func contactPicker(_ picker: CNContactPickerViewController, didSelect contact: CNContact) {
        contactContinuation?.resume(returning: contact)
        contactContinuation = nil
        picker.dismiss(animated: true, completion: nil)
    }
    
    func contactPickerDidCancel(_ picker: CNContactPickerViewController) {
        contactContinuation?.resume(returning: nil)
        contactContinuation = nil
    }
    
    func callAsFunction() async -> CNContact? {
        return await pickContact()
    }
}

class ViewController: UIViewController, CNContactPickerDelegate {
    
    
    @IBOutlet weak var contactNameLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func chooseContactTouchUpInside(_ sender: Any) {
        async {
            let contact = await ContactPicker(viewController: self)()
            self.contactNameLabel.text = contact?.givenName
        }
    }
}
