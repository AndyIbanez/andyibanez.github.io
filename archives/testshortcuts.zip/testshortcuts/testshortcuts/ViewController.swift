//
//  ViewController.swift
//  testshortcuts
//
//  Created by Andy Ibanez on 12/12/19.
//  Copyright © 2019 BNB. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view.
  }


}

