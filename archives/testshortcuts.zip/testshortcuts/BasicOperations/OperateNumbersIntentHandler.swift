//
//  OperateNumbersIntentHandler.swift
//  BasicOperations
//
//  Created by Andy Ibanez on 12/12/19.
//  Copyright © 2019 BNB. All rights reserved.
//

import Foundation

class OperateNumbersIntentHandler: NSObject, OperateNumbersIntentHandling {
  func operate(with operation: Operation, firstNumber: Int, secondNumber: Int) -> Int {
    switch operation {
    case .addition: return firstNumber + secondNumber
    case .substraction: return firstNumber - secondNumber
    default: fatalError("Invalid operation")
    }
  }
  
  func handle(intent: OperateNumbersIntent, completion: @escaping (OperateNumbersIntentResponse) -> Void) {
    
    let opResult = operate(with: intent.operation,
                           firstNumber: intent.firstNumber!.intValue,
                           secondNumber: intent.secondNumber!.intValue)
    
    let result = OperateNumbersIntentResponse.success(addition: NSNumber(value: opResult))
    
    completion(result)
    
  }
  
  func resolveSecondNumber(for intent: OperateNumbersIntent, with completion: @escaping (OperateNumbersSecondNumberResolutionResult) -> Void) {
    var result: OperateNumbersSecondNumberResolutionResult = .unsupported()
    
    defer { completion(result) }
    
    if let number = intent.secondNumber?.intValue {
      result = OperateNumbersSecondNumberResolutionResult.success(with: number)
    }
  }
  
  func resolveFirstNumber(for intent: OperateNumbersIntent, with completion: @escaping (OperateNumbersFirstNumberResolutionResult) -> Void) {
    var result: OperateNumbersFirstNumberResolutionResult = .unsupported()
    
    defer { completion(result) }
    
    if let number = intent.firstNumber?.intValue {
      result = OperateNumbersFirstNumberResolutionResult.success(with: number)
    }
  }
  
  func resolveOperation(for intent: OperateNumbersIntent, with completion: @escaping (OperationResolutionResult) -> Void) {
    var result: OperationResolutionResult = .unsupported()
    
    defer { completion(result) }
    
    let operation = intent.operation
    if operation != .unknown {
      result = .success(with: operation)
    }
  }
}
